/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfacejogo.Position;
import interfacejogo.Ships;

/**
 *
 * @author plima
 */
public class Table {
    public Position local[][] = new Position[10][10];
    private Ships ships;
}
